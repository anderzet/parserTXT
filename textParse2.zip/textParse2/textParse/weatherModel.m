//
//  Model.m
//  textParse
//
//  Created by Andrew on 16.01.17.
//  Copyright © 2017 zetDev. All rights reserved.
//

#import "weatherModel.h"

@implementation weatherModel



@end
