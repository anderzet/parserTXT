//
//  CostomeTableViewCell.m
//  textParse
//
//  Created by Andrew on 16.01.17.
//  Copyright © 2017 zetDev. All rights reserved.
//

#import "CostomeTableViewCell.h"

@implementation CostomeTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
