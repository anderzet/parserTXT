//
//  Model.h
//  textParse
//
//  Created by Andrew on 16.01.17.
//  Copyright © 2017 zetDev. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface weatherModel : NSObject

@property (strong, nonatomic) NSString* year;
@property (strong, nonatomic) NSString* mm;
@property (strong, nonatomic) NSString* tmax;
@property (strong, nonatomic) NSString* tmin;
@property (strong, nonatomic) NSString* days;
@property (strong, nonatomic) NSString* rain;
@property (strong, nonatomic) NSString* sun_hours;


@end
