//
//  ViewController.m
//  textParse
//
//  Created by Andrew on 16.01.17.
//  Copyright © 2017 zetDev. All rights reserved.
//

#import "ViewController.h"
#import "weatherModel.h"
#import "CostomeTableViewCell.h"
#import <AFNetworking.h>
#import <KVNProgress/KVNProgress.h>

@interface ViewController ()<UITableViewDataSource>{
    
    NSMutableArray* arrayFiles;
    NSMutableArray* sortedFiles;

}

@property (weak, nonatomic) IBOutlet UITableView *myTable;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    arrayFiles = [NSMutableArray new];
    sortedFiles = [NSMutableArray new];
    
    
    [self downloadFiles];



}

- (void) downloadFiles{
    
    [KVNProgress showWithStatus:@"Загрузка..."];

    NSURL *URL = [NSURL URLWithString:@"http://www.metoffice.gov.uk/pub/data/weather/uk/climate/stationdata/bradforddata.txt"];
    
    
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithURL:URL
            completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                
               NSString *result = [[NSString alloc]
                                    initWithData :data encoding:
                                    NSASCIIStringEncoding];
                
                
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                        [self parser:result];
                        dispatch_async(dispatch_get_main_queue(), ^ {
                            [KVNProgress dismiss];
                            [_myTable reloadData];
                        });
                    });
                
            }] resume];
    
    
   // NSLog(@"Result = %@", result);
    
    
}

- (void)parser:(NSString*)result{
    
    
    
    NSArray *lines = [result componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"\r\n"]];
    
    
    
    for (int i = 7; i < lines.count; i++) {
    
        NSString* line = [lines objectAtIndex:i];
        
        NSMutableArray* files = [NSMutableArray new];
        
        NSArray *values = [line componentsSeparatedByString:@" "];
        
        for (NSString* str in values) {
            
            if ([str isEqualToString:@""]) {
                
               // NSLog(@"Not strings");
                
            } else {
                
                [files addObject:str];
                
            }
        }
        
        /////
        
        if (files.count == 0) {
            
            ///
        }else{
        
        weatherModel* model = [weatherModel new];
        model.year = [files objectAtIndex:0];
        model.mm =   [files objectAtIndex:1];
        model.tmax = [files objectAtIndex:2];
        model.tmin = [files objectAtIndex:3];
        model.days = [files objectAtIndex:4];
        model.rain = [files objectAtIndex:5];
        model.sun_hours = [files objectAtIndex:6];
        
        [arrayFiles addObject:model];
            
                }
        
       
    }
}

/////

-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    //minimum size of your cell, it should be single line of label if you are not clear min. then return UITableViewAutomaticDimension;
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    return UITableViewAutomaticDimension;
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return arrayFiles.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString* cellIdentifer = @"cell";
    
    CostomeTableViewCell* cell = [_myTable dequeueReusableCellWithIdentifier:cellIdentifer];
    
    if (!cell) {
        cell = [[CostomeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifer];
    }
    
    weatherModel* model = [arrayFiles objectAtIndex:indexPath.row];
    
    cell.yearLabel.text = [NSString stringWithFormat:@"%@ year",model.year];
    cell.mmLabel.text   = [NSString stringWithFormat:@"%@ mm",model.mm];
    cell.tmaxLabel.text = [NSString stringWithFormat:@"tmax %@",model.tmax];
    cell.tminLabel.text = [NSString stringWithFormat:@"tmin %@",model.tmin];
    cell.daysLabek.text = [NSString stringWithFormat:@"%@ days",model.days];
    cell.rainLabel.text = [NSString stringWithFormat:@"rain %@ mm",model.rain];
    cell.sunLabel.text =  [NSString stringWithFormat:@"sun %@ hours", model.sun_hours];

    
    

    return cell;
    
}




@end
