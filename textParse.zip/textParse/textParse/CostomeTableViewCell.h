//
//  CostomeTableViewCell.h
//  textParse
//
//  Created by Andrew on 16.01.17.
//  Copyright © 2017 zetDev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CostomeTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *yyyyLabel;
@property (weak, nonatomic) IBOutlet UILabel *mmLabel;
@property (weak, nonatomic) IBOutlet UILabel *tmaxLabel;
@property (weak, nonatomic) IBOutlet UILabel *tminLabel;
@property (weak, nonatomic) IBOutlet UILabel *daysLabek;
@property (weak, nonatomic) IBOutlet UILabel *rainLabel;
@property (weak, nonatomic) IBOutlet UILabel *sunLabel;

@end
