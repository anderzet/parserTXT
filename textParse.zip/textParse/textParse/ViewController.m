//
//  ViewController.m
//  textParse
//
//  Created by Andrew on 16.01.17.
//  Copyright © 2017 zetDev. All rights reserved.
//

#import "ViewController.h"
#import "Model.h"
#import "CostomeTableViewCell.h"

@interface ViewController ()<UITableViewDataSource>{
    
    NSMutableArray* arrayFiles;
    NSMutableArray* sortedFiles;


}
@property (weak, nonatomic) IBOutlet UITableView *myTable;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    arrayFiles = [NSMutableArray new];
    sortedFiles = [NSMutableArray new];
    
    [self parser];
    
}

- (void)parser{
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"file" ofType:@"txt"];
    NSString *contents = [NSString stringWithContentsOfFile:path encoding:NSASCIIStringEncoding error:nil];
    
    NSArray *lines = [contents componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"\r\n"]];
    
    
    for (NSString* line in lines) {
        
        NSMutableArray* files = [NSMutableArray new];
        
        NSArray *values = [line componentsSeparatedByString:@" "];
        
        for (NSString* str in values) {
            
            if ([str isEqualToString:@""]) {
                
                NSLog(@"Not strings");
                
            } else {
                
                [files addObject:str];
                
            }
        }
        
        /////
        
        if (arrayFiles.count < 200) { //// количество добавляемих моделей
            
            Model* model = [Model new];
            model.yyyy = [files objectAtIndex:0];
            model.mm =   [files objectAtIndex:1];
            model.tmax = [files objectAtIndex:2];
            model.tmin = [files objectAtIndex:3];
            model.days = [files objectAtIndex:4];
            model.rain = [files objectAtIndex:5];
            model.sun_hours = [files objectAtIndex:6];
            
            [arrayFiles addObject:model];
            
           // NSLog(@"array count %li", arrayFiles.count);
        }else{
            ///
        }
        
    }
}


#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return arrayFiles.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString* cellIdentifer = @"cell";
    
    CostomeTableViewCell* cell = [_myTable dequeueReusableCellWithIdentifier:cellIdentifer];
    
    if (!cell) {
        cell = [[CostomeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifer];
    }
    
    Model* model = [arrayFiles objectAtIndex:indexPath.row];
    
    cell.yyyyLabel.text = [NSString stringWithFormat:@"%@ yyyy",model.yyyy];
    cell.mmLabel.text   = [NSString stringWithFormat:@"%@ mm",model.mm];
    cell.tmaxLabel.text = [NSString stringWithFormat:@"tmax %@",model.tmax];
    cell.tminLabel.text = [NSString stringWithFormat:@"tmin %@",model.tmin];
    cell.daysLabek.text = [NSString stringWithFormat:@"%@ days",model.days];
    cell.rainLabel.text = [NSString stringWithFormat:@"rain %@ mm",model.rain];
    cell.sunLabel.text =  [NSString stringWithFormat:@"sun %@ hours", model.sun_hours];

    
    

    return cell;
    
}




@end
